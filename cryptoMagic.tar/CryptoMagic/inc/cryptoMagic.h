/*
*Filename: cryptoMagic.h
*Project: cryptoMagic
*Programmer: Ning Li
*Date: 2021-02-06
*Description: this file includes all libraries, prototypes and some constants. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//constants
#define kNumChars 11
#define kMaxInput 121
#define kMaxOutput 256

//prototypes
void encryptMode(char originalFile[]);
void decryptMode(char originalFile[]);
void getBaseFilename(char originalFile[], char baseFilename[]);
void addExt(char baseFilename[], char mode);
void encryptAndWrite(char inputString[], FILE* fpOutput);
void decryptAndWrite(char inputString[], FILE* fpOutput);
