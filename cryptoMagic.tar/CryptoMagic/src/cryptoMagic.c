/*
*Filename: cryptoMagic.c
*Project: cryptoMagic
*Programmer: Ning Li
*Date: 2021-02-06
*Description: This program will take any ASCII file and encrypt it in such a way that its contents are not readable
               until they are decrypted by the utility.
*/

#include "../inc/cryptoMagic.h"

int main(int argc, char* argv[])
{
	const char encryptSwitch[kNumChars] = "-encrypt";
	const char decryptSwitch[kNumChars] = "-decrypt";
	
	if (argc == 1)
	{
		printf("Need at least one argument!\nFormat:<Program> <-Switch> <Filename>\n");		
	}
	else if (argc == 2) 
	{		
		encryptMode(argv[1]);
	}
	else if (argc == 3) 
	{
		if (strcmp(argv[1], encryptSwitch) == 0)
		{			
			encryptMode(argv[2]);
		}
		else if (strcmp(argv[1], decryptSwitch) == 0)
		{
			decryptMode(argv[2]);
		}
		else 
		{
			printf("INVALID input!\nFormat:<Program> <-Switch> <Filename>\n");			
		}
	}
	else 
	{
		printf("Too many arguments!\nFormat:<Program> <-Switch> <Filename>\n");		
	}

	return 0;
}

