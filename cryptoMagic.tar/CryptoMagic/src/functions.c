/*
*Filename: functions.c
*Project: cryptoMagic
*Programmer: Ning Li
*Date: 2021-02-06
*Description: this file includes all functions used in this program.
*/


#include "../inc/cryptoMagic.h"


/*
Function: encryptMode
Parameter: char originalFile[]
Return: nothing
Description: This function takes a file with any extension and creates the encrypted file with .crp extension.
*/


void encryptMode(char originalFile[])
{
	char mode = 'e';
	char filename[kMaxInput] = "";
	char buffer[kMaxInput] = "";

	//get base filename and append the .crp suffix
	getBaseFilename(originalFile, filename);
	addExt(filename, mode);

	//Open the original file
	FILE* fpOriginal = fopen(originalFile, "r");
	if (fpOriginal == NULL)
	{
		printf("File does not exist!\n");
		return;
	}

	//make and open a new output file
	FILE* fpOutput = fopen(filename, "w");
	if (fpOutput == NULL)
	{
		printf("Cannot make an output file!\n");
		return;
	}

	//get one line content untill get the end of the file
	while(feof(fpOriginal) == 0)
	{
		if (fgets(buffer, kMaxInput, fpOriginal) != NULL) 
		{
			//call the encryptAndWrite function 
			encryptAndWrite(buffer, fpOutput);

			//clear the buffer string
			memset(buffer, 0, sizeof(buffer));
		}
	}

	// close files
	if (fclose(fpOriginal) != 0)
	{
		printf("failed to close the original file!\n");
	}

	if (fclose(fpOutput) != 0)
	{
		printf("Failed to close the output file!\n");
	}	
}


/*
Function: decryptMode
Parameter: char originalFile[]
Return : nothing
Description: This function takes an encrypted file and create a decrypted file with .txt extension
*/

void decryptMode(char originalFile[])
{
	char mode = 'd';
	char filename[kMaxInput] = "";
	char buffer[kMaxInput] = "";

	//get base filename from the path and append the .txt suffix
	getBaseFilename(originalFile, filename);
	addExt(filename, mode);

	//open original file
	FILE* fpOriginal = fopen(originalFile, "r");
	if (fpOriginal == NULL)
	{
		printf("File does not exist!\n");
		return;
	}
	
	//make and open a new output file
	FILE* fpOutput = fopen(filename, "w");
	if (fpOutput == NULL)
	{
		printf("Cannot make an output file!\n");
		return;
	}

	//get one line content untill get the end of the file
	while(feof(fpOriginal) == 0)
	{
		if (fgets(buffer, kMaxInput, fpOriginal) != NULL) 
		{
			//call the decryptAndWrite function 
			decryptAndWrite(buffer, fpOutput);

			//clear the buffer string
			memset(buffer, 0, sizeof(buffer));
		}
	}

	// close files
	if (fclose(fpOriginal) != 0)
	{
		printf("failed to close the original file!\n");
	}

	if (fclose(fpOutput) != 0)
	{
		printf("Failed to close the output file!\n");
	}	
}


/*
Function: getBaseFilename
Parameter: (char originalFile[], char baseFilename[])
Return : nothing
Description: This function takes a filename from command line and determine whether the filename contains path, extension
             and parse the filename to get the base filename
*/

void getBaseFilename(char originalFile[], char baseFilename[])
{
	char slash = '/';
	char dot = '.';	

	//get the pointer of the last slash and dot
	char* pSlash = strrchr(originalFile, slash);
	char* pDot = strrchr(originalFile, dot);

	//get the base filename
	if (pSlash == NULL && pDot == NULL) 
	{
		strcpy(baseFilename, originalFile);
	}
	else if (pSlash != NULL && pDot != NULL) 
	{
		char* pCopy = pSlash + 1;
		char* pOutput = baseFilename;

		while (pCopy != pDot) 
		{
			*pOutput = *pCopy;
			pOutput++;
			pCopy++;
		}
	}
	else if (pSlash != NULL && pDot == NULL) 
	{

		char* pCopy = pSlash+1;
		strcpy(baseFilename, pCopy);
	}
	else if (pSlash == NULL && pDot != NULL) 
	{		
		char* pCopy = originalFile;
		char* pOutput = baseFilename;

		while (pCopy != pDot) 
		{
			*pOutput = *pCopy;
			pOutput++;
			pCopy++;
		}
	}
}


/*
Function: addExt
Parameter: char baseFilename[], char mode
Return : nothing
Description: This function adds .crp or .txt extension to the base filename.
*/

void addExt(char baseFilename[], char mode) 
{
	char encrypt = 'e';
	char decrypt = 'd';
	char txtExt[kNumChars] = ".txt";
	char crpExt[kNumChars] = ".crp";

	if (mode == encrypt) 
	{
		strcat(baseFilename, crpExt);
	}

	if (mode == decrypt) 
	{
		strcat(baseFilename, txtExt);
	}
}


/*
Function: encryptAndWrite
Parameter: char inputString[], FILE* fpOutput
Return : nothing
Description: This function takes the ascii values from the original file,then encrypts and writes to the ouput file.
*/

void encryptAndWrite(char inputString[], FILE* fpOutput) 
{
	char carriageReturn = '\n';
	char tab = 'T';
	char* pSource = inputString;
	int outChar=0;

	//loop untill get the end of the string
	while (*pSource != '\0') 
	{
		outChar=*pSource;

		if(outChar == 10) //means a carriage return
		{
			fprintf(fpOutput, "%c", carriageReturn);
		}
		else if (outChar == 9) //means a tab
		{
			fprintf(fpOutput, "%c", tab);
			fprintf(fpOutput, "%c", tab);
		}
		else 
		{
			outChar = outChar - 16;

			if (outChar < 32) 
			{
				outChar = (outChar - 32) + 144;
			}

			fprintf(fpOutput, "%02X", outChar);
		}
		pSource++;
	}
}



/*
Function: decryptAndWrite
Parameter: char inputString[], FILE* fpOutput
Return : nothing
Description: This function takes the ascii values from the original file,then decrypts and writes to the ouput file.
*/

void decryptAndWrite(char inputString[], FILE* fpOutput) 
{	
	char carriageReturn = '\n';
	char tab = 'T';	
	char writeTab = '\t';
	char* pSource = inputString;
	int outChar=0;

	//loop untill get the end of the string	
	while (*pSource != '\0') 
	{
		if (*pSource == tab) 
		{
			fprintf(fpOutput, "%c", writeTab);
			pSource += 2;
		}
		else if (*pSource == carriageReturn) 
		{
			fprintf(fpOutput, "%c",carriageReturn);
			pSource++;
		}
		else
		{
			int firstValue = *pSource;
			int secondValue = *(++pSource);

			//if the ascii value is between 0 and 9 
			if (firstValue >= 48 && firstValue  <= 57) 
			{
				firstValue  -= 48;
			}
			//if the ascii value is between A and F 
			else if (firstValue  >= 65 && firstValue  <= 70) 
			{
				firstValue -= 55;
			}
			
			//if the ascii value is between 0 and 9 
			if (secondValue >= 48 && secondValue <= 57) 
			{
				secondValue -= 48;
			}
			//if the ascii value is between A and F			
			else if (secondValue >= 65 && secondValue <= 70) 
			{
				secondValue -= 55;
			}

			outChar = firstValue  * 16 + secondValue + 16;

			if (outChar > 127) 
			{
				outChar = (outChar - 144) + 32;
			}

			fprintf(fpOutput, "%c", outChar);
			pSource++;
		}
	}
}

